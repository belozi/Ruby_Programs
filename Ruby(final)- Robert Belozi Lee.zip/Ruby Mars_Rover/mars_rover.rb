require './rover.rb'
require './position_methods.rb'

# This code prompts the user for the file that contains the information 
# about the area, location, and movements of the rover

puts "\nPlease enter the file containing the rover data:"
file = gets.chomp
data = File.readlines(file)

# Finds the limit of the plateau

x_limit = data[1][0]
y_limit = data[1][2] 

# This codes parses out the location, orientation, and movement data of the two rovers

# This code retrieves the original location for the two rovers

x1 = data[2][0]
y1 = data[2][2]
x2 = data[4][0]
y2 = data[4][2]

# This code retrieves the direction information

orientation_1 = data[2][4].to_s
orientation_2 = data[4][4].to_s
direction_1 = facing(orientation_1)
direction_2 = facing(orientation_2)

# This code retrieves the raw command data

commands_1 = data[3].chomp
commands_2 = data[5].chomp

# This code creates the objects that represents the two rovers

rover_1 = Rover.new(x1, y1, direction_1, x_limit, y_limit, commands_1)

rover_1.drive

rover_2 = Rover.new(x2, y2, direction_2, x_limit, y_limit, commands_2)

rover_2.drive