class Rover

	# This code creates the class that defines the attributes and methods of the rovers.

	def initialize(x, y, direction, x_limit, y_limit, commands)

		@x = x.to_i
		@y = y.to_i
		@direction = direction.to_i
		@x_limit = x_limit.to_i
		@y_limit = y_limit.to_i
		@commands = commands

		start = "(#{@x}, #{@y})"
		puts "\nThe rover's starting point is #{start}, facing #{translate_direction}\n"
	end

	# This code parses the movement commands that need to be processed

	def drive

		moves = []
		@commands.each_char do |c|
			moves << c
		end

		moves.each do |m|
			if m == "R" || m == "L"
				self.turn m
			elsif m == "M"
				self.move_forward
			else
				puts "Invalid command"
			end
		end

		last_position
	end

	# This code calculates the position of the rover after one move forward.

	def move_forward 

		case @direction
			
			when 0
				@y += 1
			when 1
				@x += 1
			when  2
				@y -= 1
			when 3
				@x -= 1
		end

			puts "(#{@x}, #{@y}), #{translate_direction}"
	end

	# This code defines a method for changing the direction of the rover.

	def turn(t)

		if t == 'R'
			if @direction ==3
				@direction = 0
			else
				@direction += 1
			end

		 elsif t == 'L'
		 	if @direction == 0
		 		@direction = 3
		 	else
		 		@direction -= 1
		 	end

		else
			puts "Invalid direction command"
		end
	end

	# This code changes the direction number into the direction name

	def translate_direction
		case @direction
		when 0
			return "North"
		when 1
			return "East"
		when 2
			return "South"
		when 3
			return "West"
		end
	end

	# This code prints the last position of the rover

	def last_position
		puts "\nThe rover has stopped.\n\nThe current position is (#{@x}, #{@y}), facing #{translate_direction}\n"

			if @x > @x_limit || @y > @y_limit
				puts "You drove the rover off of the plateau"
			end
	end
	
end
