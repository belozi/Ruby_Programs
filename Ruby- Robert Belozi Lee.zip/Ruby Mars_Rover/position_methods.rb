# This code converts the direction letter into a number that 
# can be manipulated to track turns of the rover


def facing (d)

	pointer = [0, 1, 2, 3]

	case d 

		when "N"
			direction = pointer[0]
		when "E" 
			direction = pointer[1]
		when "S" 
			direction = pointer[2]
		when "W" 
			direction = pointer[3]
	end

end 
		
	